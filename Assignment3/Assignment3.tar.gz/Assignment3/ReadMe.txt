Author: Ameerah Allie
Date: 2 April 2014
Assignment 3

Description: Stores info about files, allows them to be displayed to the user (stored in a hash table).

Sources: *.jpg's, assignment3.java, HashTable.java, HashEntry,java

Instructions:
1. Use makefile to compile
2. Run
3. Written questions included in a "Questions.txt" file
