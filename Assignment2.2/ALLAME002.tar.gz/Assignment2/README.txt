Author: Ameerah Allie
Date: 20 March 2012

Name: assignment2.java

Description: This program reads in a file and, for each name and surname in the file, caculates their frequency. It stores this information in nodes in two separate trees. It traverses through these trees, printing these names and their frequencies.

Instructions: 
1. Change to the directory where you've unzipped the files to
2. Make sure the text and java files are in the same directory
3. Run using the make command

List of files: assignment2.java, BinarySearchTree.java, Node.java, toSearchIn.java
